import React, { useState } from 'react';
import { Toaster } from 'react-hot-toast';
import { AuthProvider } from './hooks/useAuth';
import { ProductsProvider } from './hooks/useProducts';
import Header from './components/Layout/Header';
import Navigation from './components/Layout/Navigation';
import MobileMenu from './components/Layout/MobileMenu';
import Hero from './components/Home/Hero';
import ProductGrid from './components/Products/ProductGrid';
import Newsletter from './components/Home/Newsletter';
import AuthModal from './components/Auth/AuthModal';

function App() {
  const [activeSection, setActiveSection] = useState('home');
  const [searchQuery, setSearchQuery] = useState('');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login');

  const handleSearch = (query: string) => {
    setSearchQuery(query);
    setActiveSection('products');
  };

  const handleSectionChange = (section: string) => {
    setActiveSection(section);
    if (section !== 'products') {
      setSearchQuery('');
    }
  };

  const handleAuthClick = (mode: 'login' | 'register') => {
    setAuthMode(mode);
    setShowAuthModal(true);
  };

  const renderContent = () => {
    switch (activeSection) {
      case 'home':
        return (
          <>
            <Hero />
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
              <div className="text-center mb-12">
                <h2 className="text-3xl font-bold text-gray-900 mb-4">
                  Produits les plus populaires
                </h2>
                <p className="text-gray-600 max-w-2xl mx-auto">
                  Découvrez les produits numériques les plus téléchargés et les mieux notés par notre communauté
                </p>
              </div>
              <ProductGrid selectedCategory="featured" />
            </div>
            <Newsletter />
          </>
        );
      
      case 'products':
        return (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">
                {searchQuery ? 'Résultats de recherche' : 'Tous nos produits'}
              </h2>
              <p className="text-gray-600 max-w-2xl mx-auto">
                {searchQuery 
                  ? `Produits correspondant à "${searchQuery}"`
                  : 'Explorez notre collection complète de produits numériques'
                }
              </p>
            </div>
            <ProductGrid searchQuery={searchQuery} />
          </div>
        );
      
      case 'formations':
        return (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">
                Formations
              </h2>
              <p className="text-gray-600 max-w-2xl mx-auto">
                Développez vos compétences avec nos formations vidéo professionnelles
              </p>
            </div>
            <ProductGrid selectedCategory="formation" />
          </div>
        );
      
      case 'services':
        return (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">
                Services
              </h2>
              <p className="text-gray-600 max-w-2xl mx-auto">
                Bénéficiez de services personnalisés pour votre business
              </p>
            </div>
            <ProductGrid selectedCategory="coaching" />
          </div>
        );
      
      case 'blog':
        return (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
            <div className="text-center">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">
                Blog
              </h2>
              <p className="text-gray-600 max-w-2xl mx-auto">
                Articles et conseils pour réussir dans le digital
              </p>
              <div className="mt-12">
                <p className="text-gray-500">Section en cours de développement...</p>
              </div>
            </div>
          </div>
        );
      
      case 'contact':
        return (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
            <div className="text-center">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">
                Contact
              </h2>
              <p className="text-gray-600 max-w-2xl mx-auto mb-8">
                Une question ? Nous sommes là pour vous aider
              </p>
              <div className="bg-white rounded-2xl shadow-lg p-8 max-w-2xl mx-auto">
                <div className="space-y-6">
                  <div>
                    <h3 className="font-semibold text-gray-900 mb-2">📧 Email</h3>
                    <p className="text-gray-600">contact@smartdigitalpro.mg</p>
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900 mb-2">📱 Téléphone</h3>
                    <p className="text-gray-600">+261 32 12 345 67</p>
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900 mb-2">📍 Adresse</h3>
                    <p className="text-gray-600">Antananarivo, Madagascar</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        );
      
      default:
        return null;
    }
  };

  return (
    <AuthProvider>
      <ProductsProvider>
        <div className="min-h-screen bg-gray-50">
          <Header 
            onSearch={handleSearch}
            onToggleMobileMenu={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            isMobileMenuOpen={isMobileMenuOpen}
          />
          
          <Navigation 
            activeSection={activeSection}
            onSectionChange={handleSectionChange}
          />
          
          <MobileMenu
            isOpen={isMobileMenuOpen}
            onClose={() => setIsMobileMenuOpen(false)}
            activeSection={activeSection}
            onSectionChange={handleSectionChange}
            onAuthClick={handleAuthClick}
          />

          <main>
            {renderContent()}
          </main>

          {/* Footer */}
          <footer className="bg-gray-900 text-white py-12">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
                <div>
                  <h3 className="text-xl font-bold mb-4 bg-gradient-to-r from-green-400 to-red-400 bg-clip-text text-transparent">
                    SmartDigitalPro
                  </h3>
                  <p className="text-gray-400">
                    Votre plateforme de référence pour les produits numériques à Madagascar.
                  </p>
                </div>
                
                <div>
                  <h4 className="font-semibold mb-4">Liens rapides</h4>
                  <ul className="space-y-2 text-gray-400">
                    <li><button onClick={() => handleSectionChange('home')} className="hover:text-white transition-colors">Accueil</button></li>
                    <li><button onClick={() => handleSectionChange('products')} className="hover:text-white transition-colors">Produits</button></li>
                    <li><button onClick={() => handleSectionChange('formations')} className="hover:text-white transition-colors">Formations</button></li>
                    <li><button onClick={() => handleSectionChange('services')} className="hover:text-white transition-colors">Services</button></li>
                  </ul>
                </div>
                
                <div>
                  <h4 className="font-semibold mb-4">Support</h4>
                  <ul className="space-y-2 text-gray-400">
                    <li><a href="#" className="hover:text-white transition-colors">FAQ</a></li>
                    <li><button onClick={() => handleSectionChange('contact')} className="hover:text-white transition-colors">Contact</button></li>
                    <li><a href="#" className="hover:text-white transition-colors">Politique de confidentialité</a></li>
                    <li><a href="#" className="hover:text-white transition-colors">Conditions d'utilisation</a></li>
                  </ul>
                </div>
                
                <div>
                  <h4 className="font-semibold mb-4">Suivez-nous</h4>
                  <div className="flex space-x-4">
                    <a href="#" className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center hover:bg-blue-700 transition-colors">
                      F
                    </a>
                    <a href="#" className="w-8 h-8 bg-pink-600 rounded-full flex items-center justify-center hover:bg-pink-700 transition-colors">
                      I
                    </a>
                    <a href="#" className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center hover:bg-blue-600 transition-colors">
                      L
                    </a>
                  </div>
                </div>
              </div>
              
              <div className="border-t border-gray-800 pt-8 mt-8 text-center text-gray-400">
                <p>&copy; 2024 SmartDigitalPro. Tous droits réservés. Fait avec ❤️ à Madagascar.</p>
              </div>
            </div>
          </footer>

          {showAuthModal && (
            <AuthModal
              mode={authMode}
              onClose={() => setShowAuthModal(false)}
              onToggleMode={() => setAuthMode(authMode === 'login' ? 'register' : 'login')}
            />
          )}

          <Toaster
            position="top-right"
            toastOptions={{
              duration: 4000,
              style: {
                background: '#363636',
                color: '#fff',
              },
            }}
          />
        </div>
      </ProductsProvider>
    </AuthProvider>
  );
}

export default App;
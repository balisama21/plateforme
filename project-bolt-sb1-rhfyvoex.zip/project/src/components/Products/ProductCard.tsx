import React from 'react';
import { motion } from 'framer-motion';
import { Heart, Download, Eye, Star, Edit, Trash2 } from 'lucide-react';
import { Product } from '../../types';
import { useAuth } from '../../hooks/useAuth';
import { useProducts } from '../../hooks/useProducts';

interface ProductCardProps {
  product: Product;
  onView: (product: Product) => void;
  onEdit?: (product: Product) => void;
  index: number;
}

export default function ProductCard({ product, onView, onEdit, index }: ProductCardProps) {
  const { user, isAuthenticated } = useAuth();
  const { likeProduct, deleteProduct } = useProducts();
  
  const isOwner = isAuthenticated && user?.id === product.seller_id;

  const handleLike = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (isAuthenticated) {
      likeProduct(product.id);
    }
  };

  const handleEdit = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (onEdit) {
      onEdit(product);
    }
  };

  const handleDelete = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (window.confirm('Êtes-vous sûr de vouloir supprimer ce produit ?')) {
      deleteProduct(product.id);
    }
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('fr-MG').format(price) + ' MGA';
  };

  return (
    <motion.div
      className="bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-2xl transition-all duration-300 group cursor-pointer"
      initial={{ opacity: 0, y: 50 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.1, duration: 0.5 }}
      whileHover={{ y: -10, scale: 1.02 }}
      onClick={() => onView(product)}
    >
      {/* Image Container */}
      <div className="relative overflow-hidden">
        <motion.img
          src={product.image_url}
          alt={product.title}
          className="w-full h-48 object-cover group-hover:scale-110 transition-transform duration-500"
          whileHover={{ scale: 1.1 }}
        />
        
        {/* Badges */}
        <div className="absolute top-3 left-3 flex flex-col space-y-2">
          {product.is_featured && (
            <motion.div
              className="bg-yellow-500 text-white px-2 py-1 rounded-full text-xs font-bold"
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: 0.3 }}
            >
              ⭐ Featured
            </motion.div>
          )}
          {product.is_top_seller && (
            <motion.div
              className="bg-red-500 text-white px-2 py-1 rounded-full text-xs font-bold"
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: 0.4 }}
            >
              🔥 Top Seller
            </motion.div>
          )}
          {product.discount && (
            <motion.div
              className="bg-green-500 text-white px-2 py-1 rounded-full text-xs font-bold"
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: 0.5 }}
            >
              -{product.discount}%
            </motion.div>
          )}
        </div>

        {/* Like Button */}
        <motion.button
          onClick={handleLike}
          className="absolute top-3 right-3 p-2 bg-white/80 backdrop-blur-sm rounded-full shadow-lg hover:bg-white transition-all"
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
        >
          <Heart className="w-4 h-4 text-red-500" />
        </motion.button>

        {/* Category Tag */}
        <div className="absolute bottom-3 left-3">
          <span className="bg-white/90 backdrop-blur-sm text-gray-800 px-3 py-1 rounded-full text-xs font-medium">
            {product.category}
          </span>
        </div>
      </div>

      {/* Content */}
      <div className="p-6">
        <h3 className="font-bold text-lg text-gray-900 mb-2 line-clamp-2 group-hover:text-green-600 transition-colors">
          {product.title}
        </h3>
        
        <p className="text-gray-600 text-sm mb-4 line-clamp-2">
          {product.description}
        </p>

        {/* Rating */}
        <div className="flex items-center space-x-2 mb-4">
          <div className="flex items-center">
            {[...Array(5)].map((_, i) => (
              <Star
                key={i}
                className={`w-4 h-4 ${
                  i < Math.floor(product.rating)
                    ? 'text-yellow-400 fill-current'
                    : 'text-gray-300'
                }`}
              />
            ))}
          </div>
          <span className="text-sm text-gray-500">({product.rating})</span>
        </div>

        {/* Price */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-2">
            <span className="text-2xl font-bold text-green-600">
              {formatPrice(product.price)}
            </span>
            {product.old_price && (
              <span className="text-sm text-gray-500 line-through">
                {formatPrice(product.old_price)}
              </span>
            )}
          </div>
          <div className="flex items-center space-x-1 text-gray-500 text-sm">
            <Download className="w-4 h-4" />
            <span>{product.downloads}</span>
          </div>
        </div>

        {/* Seller */}
        <p className="text-sm text-gray-500 mb-4">
          Par <span className="font-medium">{product.seller_name}</span>
        </p>

        {/* Actions */}
        <div className="flex space-x-2">
          <motion.button
            className="flex-1 bg-green-600 text-white py-2 px-4 rounded-xl font-medium hover:bg-green-700 transition-colors flex items-center justify-center space-x-2"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={(e) => {
              e.stopPropagation();
              // Handle download
            }}
          >
            <Download className="w-4 h-4" />
            <span>Télécharger</span>
          </motion.button>
          
          <motion.button
            className="px-4 py-2 border border-gray-300 rounded-xl hover:bg-gray-50 transition-colors flex items-center justify-center"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={(e) => {
              e.stopPropagation();
              onView(product);
            }}
          >
            <Eye className="w-4 h-4" />
          </motion.button>
        </div>

        {/* Owner Actions */}
        {isOwner && (
          <div className="flex space-x-2 mt-3 pt-3 border-t border-gray-100">
            <motion.button
              onClick={handleEdit}
              className="flex-1 bg-yellow-500 text-white py-2 px-3 rounded-lg font-medium hover:bg-yellow-600 transition-colors flex items-center justify-center space-x-2"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              <Edit className="w-4 h-4" />
              <span>Modifier</span>
            </motion.button>
            
            <motion.button
              onClick={handleDelete}
              className="flex-1 bg-red-500 text-white py-2 px-3 rounded-lg font-medium hover:bg-red-600 transition-colors flex items-center justify-center space-x-2"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              <Trash2 className="w-4 h-4" />
              <span>Supprimer</span>
            </motion.button>
          </div>
        )}
      </div>
    </motion.div>
  );
}
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Filter, Grid, List, Search, X } from 'lucide-react';
import { Product } from '../../types';
import { useProducts } from '../../hooks/useProducts';
import ProductCard from './ProductCard';
import ProductModal from './ProductModal';

interface ProductGridProps {
  searchQuery?: string;
  selectedCategory?: string;
}

const categories = [
  { value: 'all', label: 'Tous les produits' },
  { value: 'featured', label: 'Produits phares' },
  { value: 'top-seller', label: 'Meilleures ventes' },
  { value: 'canva', label: 'Modèles Canva' },
  { value: 'ebook', label: 'E-books' },
  { value: 'formation', label: 'Formations' },
  { value: 'coaching', label: 'Coaching' },
];

export default function ProductGrid({ searchQuery, selectedCategory = 'all' }: ProductGridProps) {
  const { products, searchProducts, filterProducts, isLoading } = useProducts();
  const [filteredProducts, setFilteredProducts] = useState<Product[]>([]);
  const [activeFilter, setActiveFilter] = useState(selectedCategory);
  const [sortBy, setSortBy] = useState<'newest' | 'price_low' | 'price_high' | 'popular'>('newest');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [showFilters, setShowFilters] = useState(false);

  useEffect(() => {
    let result: Product[] = [];

    if (searchQuery && searchQuery.trim()) {
      result = searchProducts(searchQuery);
    } else {
      result = filterProducts(activeFilter);
    }

    // Sort products
    switch (sortBy) {
      case 'price_low':
        result.sort((a, b) => a.price - b.price);
        break;
      case 'price_high':
        result.sort((a, b) => b.price - a.price);
        break;
      case 'popular':
        result.sort((a, b) => b.likes - a.likes);
        break;
      case 'newest':
      default:
        result.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
        break;
    }

    setFilteredProducts(result);
  }, [searchQuery, activeFilter, sortBy, products, searchProducts, filterProducts]);

  const handleFilterChange = (filter: string) => {
    setActiveFilter(filter);
    setShowFilters(false);
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-green-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Chargement des produits...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Search Results Header */}
      {searchQuery && (
        <motion.div
          className="bg-green-50 border border-green-200 rounded-lg p-4"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-green-800 font-medium">
                Résultats pour "{searchQuery}"
              </p>
              <p className="text-green-600 text-sm">
                {filteredProducts.length} produit(s) trouvé(s)
              </p>
            </div>
            <button
              onClick={() => window.location.reload()}
              className="p-2 text-green-600 hover:bg-green-100 rounded-full transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </motion.div>
      )}

      {/* Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        {/* Filters */}
        <div className="flex items-center space-x-4">
          <button
            onClick={() => setShowFilters(!showFilters)}
            className="md:hidden flex items-center space-x-2 px-4 py-2 bg-gray-100 rounded-lg"
          >
            <Filter className="w-4 h-4" />
            <span>Filtres</span>
          </button>

          <div className="hidden md:flex items-center space-x-2 overflow-x-auto">
            {categories.map((category) => (
              <motion.button
                key={category.value}
                onClick={() => handleFilterChange(category.value)}
                className={`px-4 py-2 rounded-full whitespace-nowrap transition-all ${
                  activeFilter === category.value
                    ? 'bg-green-600 text-white'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                {category.label}
              </motion.button>
            ))}
          </div>
        </div>

        {/* Sort and View Controls */}
        <div className="flex items-center space-x-4">
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as any)}
            className="px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
          >
            <option value="newest">Plus récents</option>
            <option value="popular">Plus populaires</option>
            <option value="price_low">Prix croissant</option>
            <option value="price_high">Prix décroissant</option>
          </select>

          <div className="flex items-center border border-gray-300 rounded-lg overflow-hidden">
            <button
              onClick={() => setViewMode('grid')}
              className={`p-2 ${viewMode === 'grid' ? 'bg-green-600 text-white' : 'text-gray-600 hover:bg-gray-100'}`}
            >
              <Grid className="w-4 h-4" />
            </button>
            <button
              onClick={() => setViewMode('list')}
              className={`p-2 ${viewMode === 'list' ? 'bg-green-600 text-white' : 'text-gray-600 hover:bg-gray-100'}`}
            >
              <List className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Filters */}
      <AnimatePresence>
        {showFilters && (
          <motion.div
            className="md:hidden bg-white border border-gray-200 rounded-lg p-4"
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
          >
            <div className="grid grid-cols-2 gap-2">
              {categories.map((category) => (
                <button
                  key={category.value}
                  onClick={() => handleFilterChange(category.value)}
                  className={`px-3 py-2 rounded-lg text-sm transition-all ${
                    activeFilter === category.value
                      ? 'bg-green-600 text-white'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  {category.label}
                </button>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Results Count */}
      <div className="flex items-center justify-between">
        <p className="text-gray-600">
          {filteredProducts.length} produit(s) {searchQuery ? 'trouvé(s)' : 'disponible(s)'}
        </p>
      </div>

      {/* Products Grid */}
      {filteredProducts.length > 0 ? (
        <motion.div
          className={`grid gap-6 ${
            viewMode === 'grid' 
              ? 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4' 
              : 'grid-cols-1'
          }`}
          layout
        >
          <AnimatePresence>
            {filteredProducts.map((product, index) => (
              <ProductCard
                key={product.id}
                product={product}
                onView={setSelectedProduct}
                index={index}
              />
            ))}
          </AnimatePresence>
        </motion.div>
      ) : (
        <motion.div
          className="text-center py-12"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
        >
          <Search className="w-16 h-16 text-gray-400 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-gray-900 mb-2">
            Aucun produit trouvé
          </h3>
          <p className="text-gray-600 mb-6">
            {searchQuery 
              ? `Aucun produit ne correspond à "${searchQuery}"`
              : 'Aucun produit dans cette catégorie'
            }
          </p>
          <button
            onClick={() => {
              setActiveFilter('all');
              window.location.reload();
            }}
            className="px-6 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
          >
            Voir tous les produits
          </button>
        </motion.div>
      )}

      {/* Product Modal */}
      {selectedProduct && (
        <ProductModal
          product={selectedProduct}
          onClose={() => setSelectedProduct(null)}
        />
      )}
    </div>
  );
}
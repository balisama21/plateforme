import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Heart, Download, Star, Share2, MessageCircle, Send } from 'lucide-react';
import { Product } from '../../types';
import { useAuth } from '../../hooks/useAuth';
import { useProducts } from '../../hooks/useProducts';
import toast from 'react-hot-toast';

interface ProductModalProps {
  product: Product;
  onClose: () => void;
}

export default function ProductModal({ product, onClose }: ProductModalProps) {
  const [comment, setComment] = useState('');
  const [comments] = useState([
    { id: '1', author: 'Marie Dupont', content: 'Excellent produit, très utile !', date: '2024-01-15' },
    { id: '2', author: 'Paul Martin', content: 'Je recommande vivement, qualité au top.', date: '2024-01-14' }
  ]);
  const { user, isAuthenticated } = useAuth();
  const { likeProduct } = useProducts();

  const handleLike = () => {
    if (!isAuthenticated) {
      toast.error('Vous devez être connecté pour aimer un produit');
      return;
    }
    likeProduct(product.id);
    toast.success('Produit ajouté aux favoris !');
  };

  const handleDownload = () => {
    if (!isAuthenticated) {
      toast.error('Vous devez être connecté pour télécharger');
      return;
    }
    toast.success('Téléchargement commencé !');
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: product.title,
        text: product.description,
        url: window.location.href
      });
    } else {
      navigator.clipboard.writeText(window.location.href);
      toast.success('Lien copié dans le presse-papier !');
    }
  };

  const handleCommentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!isAuthenticated) {
      toast.error('Vous devez être connecté pour commenter');
      return;
    }
    if (!comment.trim()) return;
    
    toast.success('Commentaire ajouté !');
    setComment('');
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('fr-MG').format(price) + ' MGA';
  };

  return (
    <AnimatePresence>
      <motion.div
        className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
      >
        <motion.div
          className="bg-white rounded-2xl shadow-2xl w-full max-w-4xl max-h-[90vh] overflow-hidden"
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.9, opacity: 0 }}
          onClick={e => e.stopPropagation()}
        >
          <div className="flex flex-col lg:flex-row h-full">
            {/* Image Section */}
            <div className="lg:w-1/2 relative">
              <motion.img
                src={product.image_url}
                alt={product.title}
                className="w-full h-64 lg:h-full object-cover"
                initial={{ scale: 1.1 }}
                animate={{ scale: 1 }}
                transition={{ duration: 0.5 }}
              />
              
              {/* Close Button */}
              <motion.button
                onClick={onClose}
                className="absolute top-4 right-4 p-2 bg-white/80 backdrop-blur-sm rounded-full shadow-lg hover:bg-white"
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
              >
                <X className="w-5 h-5" />
              </motion.button>

              {/* Badges */}
              <div className="absolute top-4 left-4 flex flex-col space-y-2">
                {product.is_featured && (
                  <div className="bg-yellow-500 text-white px-2 py-1 rounded-full text-xs font-bold">
                    ⭐ Featured
                  </div>
                )}
                {product.is_top_seller && (
                  <div className="bg-red-500 text-white px-2 py-1 rounded-full text-xs font-bold">
                    🔥 Top Seller
                  </div>
                )}
                {product.discount && (
                  <div className="bg-green-500 text-white px-2 py-1 rounded-full text-xs font-bold">
                    -{product.discount}%
                  </div>
                )}
              </div>
            </div>

            {/* Content Section */}
            <div className="lg:w-1/2 flex flex-col max-h-[90vh] lg:max-h-none">
              <div className="p-6 flex-1 overflow-y-auto">
                {/* Header */}
                <div className="mb-6">
                  <div className="flex items-center space-x-2 mb-2">
                    <span className="bg-green-100 text-green-800 px-3 py-1 rounded-full text-sm font-medium">
                      {product.category}
                    </span>
                  </div>
                  
                  <h1 className="text-2xl lg:text-3xl font-bold text-gray-900 mb-2">
                    {product.title}
                  </h1>
                  
                  <p className="text-gray-600 mb-4">
                    Par <span className="font-medium text-gray-900">{product.seller_name}</span>
                  </p>

                  {/* Rating */}
                  <div className="flex items-center space-x-2 mb-4">
                    <div className="flex items-center">
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          className={`w-5 h-5 ${
                            i < Math.floor(product.rating)
                              ? 'text-yellow-400 fill-current'
                              : 'text-gray-300'
                          }`}
                        />
                      ))}
                    </div>
                    <span className="text-gray-600">({product.rating})</span>
                    <span className="text-gray-400">•</span>
                    <span className="text-gray-600">{product.downloads} téléchargements</span>
                  </div>

                  {/* Price */}
                  <div className="flex items-center space-x-3 mb-6">
                    <span className="text-3xl font-bold text-green-600">
                      {formatPrice(product.price)}
                    </span>
                    {product.old_price && (
                      <span className="text-xl text-gray-500 line-through">
                        {formatPrice(product.old_price)}
                      </span>
                    )}
                  </div>

                  {/* Actions */}
                  <div className="flex space-x-3 mb-6">
                    <motion.button
                      onClick={handleDownload}
                      className="flex-1 bg-green-600 text-white py-3 px-6 rounded-xl font-medium hover:bg-green-700 transition-colors flex items-center justify-center space-x-2"
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                    >
                      <Download className="w-5 h-5" />
                      <span>Télécharger</span>
                    </motion.button>
                    
                    <motion.button
                      onClick={handleLike}
                      className="p-3 border border-gray-300 rounded-xl hover:bg-gray-50 transition-colors flex items-center justify-center"
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                    >
                      <Heart className="w-5 h-5 text-red-500" />
                      <span className="ml-1 text-sm">{product.likes}</span>
                    </motion.button>
                    
                    <motion.button
                      onClick={handleShare}
                      className="p-3 border border-gray-300 rounded-xl hover:bg-gray-50 transition-colors"
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                    >
                      <Share2 className="w-5 h-5" />
                    </motion.button>
                  </div>
                </div>

                {/* Description */}
                <div className="mb-6">
                  <h3 className="text-lg font-semibold text-gray-900 mb-3">Description</h3>
                  <p className="text-gray-600 leading-relaxed">{product.description}</p>
                </div>

                {/* Tags */}
                {product.tags && product.tags.length > 0 && (
                  <div className="mb-6">
                    <h3 className="text-lg font-semibold text-gray-900 mb-3">Tags</h3>
                    <div className="flex flex-wrap gap-2">
                      {product.tags.map((tag, index) => (
                        <span
                          key={index}
                          className="bg-gray-100 text-gray-700 px-3 py-1 rounded-full text-sm"
                        >
                          #{tag}
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                {/* Comments Section */}
                <div className="border-t border-gray-200 pt-6">
                  <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
                    <MessageCircle className="w-5 h-5 mr-2" />
                    Commentaires ({comments.length})
                  </h3>

                  {/* Comment Form */}
                  <form onSubmit={handleCommentSubmit} className="mb-6">
                    <div className="flex space-x-3">
                      <div className="flex-1">
                        <textarea
                          value={comment}
                          onChange={(e) => setComment(e.target.value)}
                          placeholder={isAuthenticated ? "Écrivez votre commentaire..." : "Connectez-vous pour commenter"}
                          rows={3}
                          disabled={!isAuthenticated}
                          className="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 resize-none disabled:bg-gray-50"
                        />
                      </div>
                      <motion.button
                        type="submit"
                        disabled={!isAuthenticated || !comment.trim()}
                        className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
                        whileHover={{ scale: isAuthenticated ? 1.05 : 1 }}
                        whileTap={{ scale: isAuthenticated ? 0.95 : 1 }}
                      >
                        <Send className="w-4 h-4" />
                      </motion.button>
                    </div>
                  </form>

                  {/* Comments List */}
                  <div className="space-y-4 max-h-64 overflow-y-auto">
                    {comments.map((comment) => (
                      <motion.div
                        key={comment.id}
                        className="bg-gray-50 rounded-lg p-4"
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                      >
                        <div className="flex items-center justify-between mb-2">
                          <h4 className="font-medium text-gray-900">{comment.author}</h4>
                          <span className="text-sm text-gray-500">{comment.date}</span>
                        </div>
                        <p className="text-gray-600">{comment.content}</p>
                      </motion.div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}
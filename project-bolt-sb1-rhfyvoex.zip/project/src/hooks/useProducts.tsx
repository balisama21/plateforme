import { createContext, useContext, useState, useEffect } from 'react';
import { Product } from '../types';

interface ProductsContextType {
  products: Product[];
  featuredProducts: Product[];
  isLoading: boolean;
  searchProducts: (query: string) => Product[];
  filterProducts: (category: string) => Product[];
  getProduct: (id: string) => Product | undefined;
  addProduct: (product: Omit<Product, 'id' | 'created_at' | 'updated_at'>) => void;
  updateProduct: (id: string, product: Partial<Product>) => void;
  deleteProduct: (id: string) => void;
  likeProduct: (id: string) => void;
}

const ProductsContext = createContext<ProductsContextType | undefined>(undefined);

// Mock products data
const mockProducts: Product[] = [
  {
    id: '1',
    title: '100 modèles Canva pour les réseaux sociaux',
    description: 'Un pack complet de 100 modèles Canva professionnels et personnalisables pour dynamiser votre présence sur les réseaux sociaux.',
    category: 'Modèles Canva',
    category_slug: 'canva',
    price: 25000,
    old_price: 35000,
    discount: 29,
    image_url: 'https://images.pexels.com/photos/3184301/pexels-photo-3184301.jpeg',
    seller_id: '1',
    seller_name: 'Jean Dupont',
    likes: 1250,
    downloads: 890,
    rating: 4.8,
    is_featured: true,
    is_top_seller: true,
    status: 'active',
    tags: ['canva', 'templates', 'social media'],
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  },
  {
    id: '2',
    title: 'E-book : Les fondamentaux du Marketing Digital',
    description: 'Découvrez les bases essentielles du marketing digital avec cet e-book complet.',
    category: 'E-books',
    category_slug: 'ebook',
    price: 15000,
    image_url: 'https://images.pexels.com/photos/159866/books-book-pages-read-literature-159866.jpeg',
    seller_id: '2',
    seller_name: 'DigitalExpert',
    likes: 800,
    downloads: 520,
    rating: 4.5,
    is_featured: false,
    is_top_seller: false,
    status: 'active',
    tags: ['ebook', 'marketing', 'digital'],
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  },
  {
    id: '3',
    title: 'Formation complète Adobe Premiere Pro',
    description: 'Maîtrisez Adobe Premiere Pro du débutant à un niveau intermédiaire avec cette formation vidéo détaillée.',
    category: 'Formations Vidéo',
    category_slug: 'formation',
    price: 50000,
    old_price: 70000,
    discount: 28,
    image_url: 'https://images.pexels.com/photos/3662770/pexels-photo-3662770.jpeg',
    seller_id: '3',
    seller_name: 'VideoMaestro',
    likes: 2100,
    downloads: 1250,
    rating: 4.9,
    is_featured: true,
    is_top_seller: true,
    status: 'active',
    tags: ['video', 'premiere pro', 'formation'],
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString()
  }
];

export function ProductsProvider({ children }: { children: React.ReactNode }) {
  const [products, setProducts] = useState<Product[]>(mockProducts);
  const [isLoading, setIsLoading] = useState(false);

  const featuredProducts = products.filter(p => p.is_featured);

  const searchProducts = (query: string): Product[] => {
    if (!query.trim()) return products;
    
    const searchTerm = query.toLowerCase().trim();
    return products.filter(product => 
      product.title.toLowerCase().includes(searchTerm) ||
      product.description.toLowerCase().includes(searchTerm) ||
      product.category.toLowerCase().includes(searchTerm) ||
      product.seller_name.toLowerCase().includes(searchTerm) ||
      product.tags.some(tag => tag.toLowerCase().includes(searchTerm))
    );
  };

  const filterProducts = (category: string): Product[] => {
    if (category === 'all') return products;
    if (category === 'featured') return featuredProducts;
    if (category === 'top-seller') return products.filter(p => p.is_top_seller);
    return products.filter(p => p.category_slug === category);
  };

  const getProduct = (id: string): Product | undefined => {
    return products.find(p => p.id === id);
  };

  const addProduct = (productData: Omit<Product, 'id' | 'created_at' | 'updated_at'>) => {
    const newProduct: Product = {
      ...productData,
      id: Date.now().toString(),
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };
    setProducts(prev => [newProduct, ...prev]);
  };

  const updateProduct = (id: string, productData: Partial<Product>) => {
    setProducts(prev => prev.map(p => 
      p.id === id 
        ? { ...p, ...productData, updated_at: new Date().toISOString() }
        : p
    ));
  };

  const deleteProduct = (id: string) => {
    setProducts(prev => prev.filter(p => p.id !== id));
  };

  const likeProduct = (id: string) => {
    setProducts(prev => prev.map(p => 
      p.id === id 
        ? { ...p, likes: p.likes + 1 }
        : p
    ));
  };

  return (
    <ProductsContext.Provider value={{
      products,
      featuredProducts,
      isLoading,
      searchProducts,
      filterProducts,
      getProduct,
      addProduct,
      updateProduct,
      deleteProduct,
      likeProduct
    }}>
      {children}
    </ProductsContext.Provider>
  );
}

export function useProducts() {
  const context = useContext(ProductsContext);
  if (context === undefined) {
    throw new Error('useProducts must be used within a ProductsProvider');
  }
  return context;
}
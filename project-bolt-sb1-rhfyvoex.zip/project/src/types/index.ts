export interface User {
  id: string;
  name: string;
  email: string;
  avatar?: string;
  role: 'buyer' | 'seller' | 'admin';
  created_at: string;
}

export interface Product {
  id: string;
  title: string;
  description: string;
  category: string;
  category_slug: string;
  price: number;
  old_price?: number;
  discount?: number;
  image_url: string;
  file_url?: string;
  preview_url?: string;
  seller_id: string;
  seller_name: string;
  likes: number;
  downloads: number;
  rating: number;
  is_featured: boolean;
  is_top_seller: boolean;
  status: 'active' | 'draft' | 'pending';
  tags: string[];
  created_at: string;
  updated_at: string;
}

export interface Comment {
  id: string;
  product_id: string;
  user_id: string;
  user_name: string;
  content: string;
  rating?: number;
  created_at: string;
}

export interface CartItem {
  id: string;
  product: Product;
  quantity: number;
}

export interface Order {
  id: string;
  user_id: string;
  items: CartItem[];
  total: number;
  status: 'pending' | 'completed' | 'cancelled';
  created_at: string;
}

export interface Notification {
  id: string;
  type: 'success' | 'error' | 'warning' | 'info';
  title: string;
  message: string;
  duration?: number;
}